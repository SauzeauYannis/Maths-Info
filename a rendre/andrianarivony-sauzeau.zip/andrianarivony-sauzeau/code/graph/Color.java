package graph;

public enum Color {
        GREEN,
        ORANGE,
        RED
}
